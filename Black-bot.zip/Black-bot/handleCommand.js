// handleCommand.js

const { menuCommand } = require('./commands/menuCommands');
const { helpCommand } = require('./commands/helpCommands');
const { addUserToGroup, banUserFromGroup, tagAllUsers, hideTag } = require('./commands/groupCommands');
const { createSticker, stickerSearch, autoReaction, antiDeleteMsg } = require('./commands/conversationCommands');
const { setStatus, saveStatus, autoReactionStatus } = require('./commands/statusCommands');
const { contactOwner } = require('./commands/ownerCommands');

const handleCommand = async (message) => {
  const command = message.body.split(' ')[0].toLowerCase();

  try {
    if (command === '!menu') {
      await menuCommand(message);
    } else if (command === '!help') {
      await helpCommand(message);
    } else if (command === '!adduser') {
      await addUserToGroup(message);
    } else if (command === '!ban') {
      await banUserFromGroup(message);
    } else if (command === '!tagall') {
      await tagAllUsers(message);
    } else if (command === '!hidetag') {
      await hideTag(message);
    } else if (command === '!sticker') {
      await createSticker(message);
    } else if (command === '!stickersearch') {
      await stickerSearch(message);
    } else if (command === '!autoreaction') {
      await autoReaction(message);
    } else if (command === '!antidelete') {
      await antiDeleteMsg(message);
    } else if (command === '!setstatus') {
      await setStatus(message);
    } else if (command === '!savestatus') {
      await saveStatus(message);
    } else if (command === '!autoreactionstatus') {
      await autoReactionStatus(message);
    } else if (command === '!contactowner') {
      await contactOwner(message);
    } else {
      message.reply('Commande inconnue. Utilisez !help pour voir la liste des commandes disponibles.');
    }
  } catch (error) {
    console.error('Erreur lors de l\'exécution de la commande:', error);
    message.reply('Une erreur est survenue lors de l\'exécution de la commande. Veuillez réessayer.');
  }
};

module.exports = { handleCommand };