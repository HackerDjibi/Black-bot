// database/config.js

require('dotenv').config(); // Charger les variables d'environnement

const OWNER_NUMBER = process.env.OWNER_NUMBER;
const OWNER_NAME = process.env.OWNER_NAME;
const PREFIX = process.env.PREFIX;
const STICKER_PACK_NAME = process.env.STICKER_PACK_NAME;
const STICKER_AUTHOR = process.env.STICKER_AUTHOR;
const DATABASE_URL = process.env.DATABASE_URL;

module.exports = {
    OWNER_NUMBER,
    OWNER_NAME,
    PREFIX,
    STICKER_PACK_NAME,
    STICKER_AUTHOR,
    DATABASE_URL
};