// helpCommands.js

const helpCommand = (message) => {
  const prefix = process.env.PREFIXE; // Récupérer le préfixe depuis les variables d'environnement
  message.reply(`
    Voici l'aide pour les commandes disponibles :
    
    - ${prefix}menu : Affiche le menu des commandes
    - ${prefix}sticker : Crée un sticker à partir d'une image
    - ${prefix}setstatus : Change le statut du bot
    - ${prefix}contact : Obtenez les informations de contact de l'owner
    - ${prefix}adduser : Ajouter un utilisateur au groupe
    - ${prefix}ban : Bannir un utilisateur du groupe
    - ${prefix}tagall : Mentionner tous les membres du groupe
    - ${prefix}hidetag : Masquer les tags
  `);
};

module.exports = helpCommand;