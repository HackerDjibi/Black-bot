// menuCommands.js
const { OWNER_NAME, PREFIX, STICKER_PACK_NAME, STICKER_AUTHOR } = require('../config');

const menuCommand = (message) => {
  message.reply(`
    Bonjour ${OWNER_NAME}, voici les commandes disponibles :
    
    Commandes principales :
    - ${PREFIX}help : Affiche l'aide
    - ${PREFIX}sticker : Crée un sticker
    - ${PREFIX}setstatus : Met à jour le statut du bot
    
    Commandes de groupe :
    - ${PREFIX}adduser : Ajouter un utilisateur au groupe
    - ${PREFIX}ban : Bannir un utilisateur du groupe
    - ${PREFIX}tagall : Mentionner tous les membres du groupe
    - ${PREFIX}hidetag : Masquer les tags
  `);
};

module.exports = menuCommand;