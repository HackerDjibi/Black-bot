// ownerCommands.js

const { OWNER_NUMBER } = require('../config');

// Commande pour obtenir les informations de contact de l'owner
const contactOwner = (message) => {
  if (!OWNER_NUMBER) {
    return message.reply("Le numéro de contact de l'owner n'est pas configuré.");
  }
  
  message.reply(`Si vous avez besoin de contacter l'owner, voici son numéro : ${OWNER_NUMBER}`);
};

module.exports = { contactOwner };