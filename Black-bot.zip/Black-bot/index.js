/*black-bot/
│
├── commandes/
│   ├── group.js
│   ├── owner.js
│   ├── conversation.js
│   └── statut.js
│
├── database/
│   └── db.js
│
├── media/
│   └── (vos fichiers médias ici)
│
├── .env
├── index.js
└── package.json
*/
// index.js

const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const { Client: PgClient } = require('pg');
const config = require('./database/config'); // Assurez-vous que le chemin est correct

// Connexion à la base de données PostgreSQL
const pgClient = new PgClient({
    connectionString: config.DATABASE_URL,
});

pgClient.connect()
    .then(() => console.log('Connecté à la base de données PostgreSQL !'))
    .catch(err => console.error('Erreur de connexion à la base de données :', err));

// Création d'une instance du client WhatsApp
const client = new Client({
    authStrategy: new LocalAuth(),
});

// Écoute des événements
client.on('qr', (qr) => {
    qrcode.generate(qr, { small: true });
});

client.on('authenticated', () => {
    console.log('Client authentifié !');
});

client.on('ready', () => {
    console.log('Client prêt à fonctionner !');
});

client.on('disconnected', (reason) => {
    console.log('Client déconnecté :', reason);
});

// Gestion des messages
client.on('message', async (message) => {
    if (message.body.startsWith(config.PREFIX)) {
        const command = message.body.slice(1).trim();
        try {
            // Exemple de réponse à une commande
            if (command === 'hello') {
                await message.reply(`Bonjour, ${config.OWNER_NAME}!`);
            }
            // Ajoutez d'autres commandes ici
        } catch (error) {
            console.error('Erreur lors du traitement de la commande:', error);
            await message.reply('Une erreur est survenue lors du traitement de votre commande. Veuillez réessayer.');
        }
    }
});

// Initialisation du client WhatsApp
client.initialize();